var msg=document.location.href;
chrome.runtime.sendMessage(msg);